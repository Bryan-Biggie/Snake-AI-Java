import java.util.Arrays;
import java.util.LinkedList;

public class Snake {
	LinkedList<SnakePosition> coordinates;
	public static LinkedList<String> drawSnake(String[] snakePostion) {
		LinkedList<String> coordinate = new LinkedList<>();
		//String[] snakePostion = snake;
		for(int i = 0; i<snakePostion.length; i++) {
			if(i  == 0) {
				coordinate = drawLine(snakePostion[i],snakePostion[i],coordinate);
			}
			else {
				coordinate = drawLine(snakePostion[i],snakePostion[i-1], coordinate);
			}
			
		}
		return coordinate;
	}
	public static LinkedList<String> drawLine(String snake,String snake1, LinkedList<String> coordinate) {
		int maxX=0, minX=0,maxY=0, minY=0;
		String[] snakePostion0 = snake.split(",");
		String[] snakePostion1 = snake1.split(",");
		
		if(Integer.parseInt(snakePostion0[0]) < Integer.parseInt(snakePostion1[0])) {
			maxX = Integer.parseInt(snakePostion1[0]);
			minX = Integer.parseInt(snakePostion0[0]);
		}
		else {
			maxX = Integer.parseInt(snakePostion0[0]);
			minX = Integer.parseInt(snakePostion1[0]);
		}
		if(Integer.parseInt(snakePostion0[1]) < Integer.parseInt(snakePostion1[1])) {
			maxY = Integer.parseInt(snakePostion1[1]);
			minY = Integer.parseInt(snakePostion0[1]);
		}
		else {
			maxY = Integer.parseInt(snakePostion0[1]);
			minY = Integer.parseInt(snakePostion1[1]);
		}
		String s,l = "";
		for(int i = 0; i<50; i++) {
			for(int j = 0; j<50; j++) {
				
				if((minX <= j && j<=maxX) && (minY <= i && i<=maxY)) {
					s = Integer.toString(i);
					l = Integer.toString(j);
					coordinate.add(l+","+s);
					//playArea[i][j] = snakeNum;
				}
			}
		}
		return coordinate;
		
	}
	
	public Snake(String snakeLine){
		coordinates = new LinkedList<SnakePosition>();
		String[] temp = snakeLine.split(" ");
		int life = 0;
		String[] copyArray = {};
		if (temp[0].equals("alive") ){
			life = 1;
			copyArray = Arrays.copyOfRange(temp, 3, temp.length);
		}else if (temp[0].equals("invisible")){
			life = 2;
			copyArray = Arrays.copyOfRange(temp, 4, temp.length);
		}
		
		LinkedList<String> Snakecoordinates = drawSnake(copyArray);
		LinkedList<String> Snakecoordinate = new LinkedList<>();
		for(String ele: Snakecoordinates)
        {
            if(!Snakecoordinate.contains(ele))
            	Snakecoordinate.add(ele);
        }
		//Snakecoordinate.removeDuplicates();
		/*for(int i = 0; i<Snakecoordinate.size(); i++) {
			System.out.print(Snakecoordinate.get(i)+" ");
		}**/
		
		if (life==1){
			for (int i=0; i<Snakecoordinate.size(); i++){
				SnakePosition sp = new SnakePosition(Snakecoordinate.get(i),",");
				coordinates.add(sp);
			}
			/*for (int i=3; i<temp.length; i++){
				SnakePosition sp = new SnakePosition(temp[i],",");
				coordinates.add(sp);
			}*/
		}
		else if (life==2){
			for (int i=0; i<Snakecoordinate.size(); i++){
				SnakePosition sp = new SnakePosition(Snakecoordinate.get(i),",");
				coordinates.add(sp);
			}
		}
	}
	
	public SnakePosition head(){
		return coordinates.get(0);
	}
	public SnakePosition kinky(){
		return coordinates.get(1);
	}
	}
