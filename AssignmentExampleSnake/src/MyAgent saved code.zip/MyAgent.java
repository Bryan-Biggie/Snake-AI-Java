import java.awt.Point;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Random;
import za.ac.wits.snake.DevelopmentAgent;

public class MyAgent extends DevelopmentAgent {

    public static void main(String args[]) {
        MyAgent agent = new MyAgent();
        MyAgent.start(agent, args);
    }

    @Override
    public void run() {
        try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))) {
            String initString = br.readLine();
            String[] temp = initString.split(" ");
            int nSnakes = Integer.parseInt(temp[0]);

            while (true) {
                String line = br.readLine();
                if (line.contains("Game Over")) {
                    break;
                }

                String apple1 = line;
                String apple2 = br.readLine();
                //do stuff with apples
              //*************************************
                SnakePosition apple;
                if(!apple1.equals("-1 -1")) {
                	apple = new SnakePosition(apple1, " ");
                }else {
                	apple = new SnakePosition(apple2, " ");
                }
				Snake mySnake = null;
				
				//*******************************

				LinkedList<Snake> otherSnakes = new LinkedList<Snake>();
                int mySnakeNum = Integer.parseInt(br.readLine());
                for (int i = 0; i < nSnakes; i++) {
                    String snakeLine = br.readLine();
                    if (i == mySnakeNum) {
                    	mySnake = new Snake(snakeLine);
                        //hey! That's me :)
                    }else {
                    	Snake NotMySnake = new Snake(snakeLine);
                    	otherSnakes.add(NotMySnake);
                    }
                    //do stuff with other snakes
                }
 // $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ DOnt use the code just for test $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
              /*  int[][] myMap = new int[50][50];

        	    
        	    for(int i = 0; i < otherSnakes.size(); i++) {
            		Snake s = otherSnakes.get(i);
            		for(int j = 0; j < s.coordinates.size(); j++) {
            			myMap[s.coordinates.get(j).y][s.coordinates.get(j).x] = 1;
            			
            		}
            	}
        	    Point[] path = new BFS().findPath(myMap, new Point(mySnake.head().y, mySnake.head().x), new Point(apple.y, apple.x));
        	    if(path != null) {
        	    int hy = mySnake.head().x;
        	    int hx = mySnake.head().y;
        	    for (Point point : path) {
        	    	if(hy == point.y) {
        	    		if(hx+1 == point.x) {//down
        	    			System.out.println(1);
            	    	}
        	    		else if(hx-1 == point.x){//up
        	    			System.out.println(0);
        	    		}
        	    	}
        	    	else if(hx == point.x) {
        	    		if(hy+1 == point.y) {//right
        	    			System.out.println(3);
            	    	}
        	    		else if(hy-1 == point.y){//left
        	    			System.out.println(2);
        	    		}
        	    	}
        	    	else if(hx-1 == point.x) {
        	    		System.out.println(0);
        	    		if(hy+1 == point.y) {//right
        	    			System.out.println(3);
            	    	}
        	    		else if(hy-1 == point.y){//left
        	    			System.out.println(2);
        	    		}
        	    	}
        	    	else if(hx+1 == point.x) {
        	    		System.out.println(1);
        	    		if(hy+1 == point.y) {//right
        	    			System.out.println(3);
            	    	}
        	    		else if(hy-1 == point.y){//left
        	    			System.out.println(2);
        	    		}
        	    	}
        	    	else if(hy-1 == point.y) {
        	    		System.out.println(2);
        	    		if(hx+1 == point.x) {//down
        	    			System.out.println(1);
            	    	}
        	    		else if(hx-1 == point.x){//up
        	    			System.out.println(0);
        	    		}
        	    	}
        	    	else if(hy+1 == point.y) {
        	    		System.out.println(3);
        	    		if(hx+1 == point.x) {//down
        	    			System.out.println(1);
            	    	}
        	    		else if(hx-1 == point.x){//up
        	    			System.out.println(0);
        	    		}
        	    	}
        	    	else {
        	    		
        	    		int move = new Random().nextInt(4);
    					System.out.println(move);
        	    	}
        	    	//myMap[point.y][point.x] = 7;
        	        //System.out.println(point.x + ", " + point.y);
        	    }
        	    }
        	    else {
    	    		
    	    		int move = new Random().nextInt(4);
					System.out.println(move);
    	    	}*/
// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ DOnt use the code just for test $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
                
// $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ DOnt use the code just for test $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
                if (apple.samelineAbove(mySnake.head(),mySnake.kinky())){
                	boolean avoidSnake = false;
                	for(int i = 0; i < otherSnakes.size(); i++) {
                		Snake s = otherSnakes.get(i);
                		for(int j = 0; j < s.coordinates.size(); j++) {
                			if(mySnake.head().y-1 ==  s.coordinates.get(j).y) {
                				avoidSnake = true;
                				break;
                			}
                		}
                		if(avoidSnake) {
                			break;
                		}
                		
                	}
                	boolean avoidMySelf = false;
            		
            	if(avoidSnake || avoidMySelf) {
                		System.out.println(1);
                	}
                	else {
                		System.out.println(0);
                	}
                }else if(apple.samelineBelow(mySnake.head(),mySnake.kinky())){
                	boolean avoidSnake = false;
                	for(int i = 0; i < otherSnakes.size(); i++) {
                		Snake s = otherSnakes.get(i);
                		for(int j = 0; j < s.coordinates.size(); j++) {
                			if(mySnake.head().y+1 ==  s.coordinates.get(j).y) {
                				avoidSnake = true;
                				break;
                			}
                		}
                		if(avoidSnake) {
                			break;
                		}
                		
                	}
                	boolean avoidMySelf = false;
            		
            	if(avoidSnake || avoidMySelf) {
                		System.out.println(0);
                	}
                	else {
                		System.out.println(1);
                	}
                	//System.out.println(1);
                }else if(apple.samelineLeft(mySnake.head(),mySnake.kinky())){
                	boolean avoidSnake = false;
                	for(int i = 0; i < otherSnakes.size(); i++) {
                		Snake s = otherSnakes.get(i);
                		for(int j = 0; j < s.coordinates.size(); j++) {
                			if(mySnake.head().x-1 ==  s.coordinates.get(j).x) {
                				avoidSnake = true;
                				break;
                			}
                		}
                		if(avoidSnake) {
                			break;
                		}
                		
                	}
                	
                	boolean avoidMySelf = false;
                		
                	if(avoidSnake || avoidMySelf) {
                		System.out.println(3);
                	}
                	else {
                		System.out.println(2);
                	}
                	//System.out.println(2);
                }else if(apple.samelineRight(mySnake.head(),mySnake.kinky())){
                	boolean avoidSnake = false;
                	for(int i = 0; i < otherSnakes.size(); i++) {
                		Snake s = otherSnakes.get(i);
                		for(int j = 0; j < s.coordinates.size(); j++) {
                			if(mySnake.head().x+1 ==  s.coordinates.get(j).x) {
                				avoidSnake = true;
                				break;
                			}
                		}
                		if(avoidSnake) {
                			break;
                		}
                		
                	}
                	
                	boolean avoidMySelf = false;
                		
                	if(avoidSnake || avoidMySelf) {
                		System.out.println(2);
                	}
                	else {
                		System.out.println(3);
                	}
                	//System.out.println(3);
                }
				
                else if (apple.above(mySnake.head())) {
                	boolean avoidSnake = false;
                	for(int i = 0; i < otherSnakes.size(); i++) {
                		Snake s = otherSnakes.get(i);
                		for(int j = 0; j < s.coordinates.size(); j++) {
                			if(mySnake.head().y-1 ==  s.coordinates.get(j).y) {
                				avoidSnake = true;
                				break;
                			}
                		}
                		if(avoidSnake) {
                			break;
                		}
                		
                	}
                	
                	boolean avoidMySelf = false;
            		
            	if(avoidSnake || avoidMySelf) {
                		System.out.println(1);
                	}
                	else {
                		System.out.println(0);
                	}
					//System.out.println(0);
				}else if (apple.below(mySnake.head())){
					boolean avoidSnake = false;
                	for(int i = 0; i < otherSnakes.size(); i++) {
                		Snake s = otherSnakes.get(i);
                		for(int j = 0; j < s.coordinates.size(); j++) {
                			if(mySnake.head().y+1 ==  s.coordinates.get(j).y) {
                				avoidSnake = true;
                				break;
                			}
                		}
                		if(avoidSnake) {
                			break;
                		}
                		
                	}
                	
                	boolean avoidMySelf = false;
                		
                	if(avoidSnake || avoidMySelf) {
                		System.out.println(0);
                	}
                	else {
                		System.out.println(1);
                	}
					//System.out.println(1);
				}else if (apple.right(mySnake.head())){
					boolean avoidSnake = false;
                	for(int i = 0; i < otherSnakes.size(); i++) {
                		Snake s = otherSnakes.get(i);
                		for(int j = 0; j < s.coordinates.size(); j++) {
                			if(mySnake.head().x+1 ==  s.coordinates.get(j).x) {
                				avoidSnake = true;
                				break;
                			}
                		}
                		if(avoidSnake) {
                			break;
                		}
                		
                	}
                	
                	boolean avoidMySelf = false;
                		
                	if(avoidSnake || avoidMySelf) {
                		System.out.println(2);
                	}
                	else {
                		System.out.println(3);
                	}
					//System.out.println(3);
				}else if (apple.left(mySnake.head())){
					boolean avoidSnake = false;
					
                	for(int i = 0; i < otherSnakes.size(); i++) {
                		Snake s = otherSnakes.get(i);
                		for(int j = 0; j < s.coordinates.size(); j++) {
                			if(mySnake.head().x-1 ==  s.coordinates.get(j).x) {
                				avoidSnake = true;
                				break;
                			}
                		}
                		if(avoidSnake) {
                			break;
                		}
                		
                	}
                	
                	boolean avoidMySelf = false;
                		
               
                	
                	if(avoidSnake || avoidMySelf) {
                		System.out.println(3);
                	}
                	else {
                		System.out.println(2);
                	}
					//System.out.println(2);
				} else {
					// finished reading, calculate move:
					int move = new Random().nextInt(4);
					System.out.println(move);
				}
                
 // $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ DOnt use the code just for test $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
                //finished reading, calculate move:
                //int move = new Random().nextInt(4);
                //System.out.println(move);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}